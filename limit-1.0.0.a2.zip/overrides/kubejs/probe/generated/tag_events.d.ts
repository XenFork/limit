/// <reference path="./globals.d.ts" />
declare namespace TagEvent {
    class PlacedFeature extends Internal.TagEventJS<any> {
    get(id: Special.PlacedFeatureTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.PlacedFeatureTag, ...id: Special.PlacedFeature[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.PlacedFeatureTag, ...id: Special.PlacedFeature[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.PlacedFeatureTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.PlacedFeature[]): Internal.TagEventJS$TagWrapper
    }
    class ConfiguredCarver extends Internal.TagEventJS<any> {
    get(id: Special.ConfiguredCarverTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.ConfiguredCarverTag, ...id: Special.ConfiguredCarver[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.ConfiguredCarverTag, ...id: Special.ConfiguredCarver[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.ConfiguredCarverTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.ConfiguredCarver[]): Internal.TagEventJS$TagWrapper
    }
    class DensityFunction extends Internal.TagEventJS<any> {
    get(id: Special.DensityFunctionTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.DensityFunctionTag, ...id: Special.DensityFunction[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.DensityFunctionTag, ...id: Special.DensityFunction[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.DensityFunctionTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.DensityFunction[]): Internal.TagEventJS$TagWrapper
    }
    class BiomeModifier extends Internal.TagEventJS<any> {
    get(id: Special.BiomeModifierTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.BiomeModifierTag, ...id: Special.BiomeModifier[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.BiomeModifierTag, ...id: Special.BiomeModifier[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.BiomeModifierTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.BiomeModifier[]): Internal.TagEventJS$TagWrapper
    }
    class Structure extends Internal.TagEventJS<any> {
    get(id: Special.StructureTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.StructureTag, ...id: Special.Structure[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.StructureTag, ...id: Special.Structure[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.StructureTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.Structure[]): Internal.TagEventJS$TagWrapper
    }
    class StructureSet extends Internal.TagEventJS<any> {
    get(id: Special.StructureSetTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.StructureSetTag, ...id: Special.StructureSet[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.StructureSetTag, ...id: Special.StructureSet[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.StructureSetTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.StructureSet[]): Internal.TagEventJS$TagWrapper
    }
    class NoiseSettings extends Internal.TagEventJS<any> {
    get(id: Special.NoiseSettingsTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.NoiseSettingsTag, ...id: Special.NoiseSettings[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.NoiseSettingsTag, ...id: Special.NoiseSettings[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.NoiseSettingsTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.NoiseSettings[]): Internal.TagEventJS$TagWrapper
    }
    class DimensionType extends Internal.TagEventJS<any> {
    get(id: Special.DimensionTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.DimensionTypeTag, ...id: Special.DimensionType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.DimensionTypeTag, ...id: Special.DimensionType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.DimensionTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.DimensionType[]): Internal.TagEventJS$TagWrapper
    }
    class ChatType extends Internal.TagEventJS<any> {
    get(id: Special.ChatTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.ChatTypeTag, ...id: Special.ChatType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.ChatTypeTag, ...id: Special.ChatType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.ChatTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.ChatType[]): Internal.TagEventJS$TagWrapper
    }
    class ConfiguredFeature extends Internal.TagEventJS<any> {
    get(id: Special.ConfiguredFeatureTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.ConfiguredFeatureTag, ...id: Special.ConfiguredFeature[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.ConfiguredFeatureTag, ...id: Special.ConfiguredFeature[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.ConfiguredFeatureTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.ConfiguredFeature[]): Internal.TagEventJS$TagWrapper
    }
    class StructureModifier extends Internal.TagEventJS<any> {
    get(id: Special.StructureModifierTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.StructureModifierTag, ...id: Special.StructureModifier[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.StructureModifierTag, ...id: Special.StructureModifier[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.StructureModifierTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.StructureModifier[]): Internal.TagEventJS$TagWrapper
    }
    class ProcessorList extends Internal.TagEventJS<any> {
    get(id: Special.ProcessorListTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.ProcessorListTag, ...id: Special.ProcessorList[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.ProcessorListTag, ...id: Special.ProcessorList[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.ProcessorListTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.ProcessorList[]): Internal.TagEventJS$TagWrapper
    }
    class WorldPreset extends Internal.TagEventJS<any> {
    get(id: Special.WorldPresetTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.WorldPresetTag, ...id: Special.WorldPreset[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.WorldPresetTag, ...id: Special.WorldPreset[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.WorldPresetTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.WorldPreset[]): Internal.TagEventJS$TagWrapper
    }
    class Biome extends Internal.TagEventJS<any> {
    get(id: Special.BiomeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.BiomeTag, ...id: Special.Biome[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.BiomeTag, ...id: Special.Biome[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.BiomeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.Biome[]): Internal.TagEventJS$TagWrapper
    }
    class Noise extends Internal.TagEventJS<any> {
    get(id: Special.NoiseTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.NoiseTag, ...id: Special.Noise[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.NoiseTag, ...id: Special.Noise[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.NoiseTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.Noise[]): Internal.TagEventJS$TagWrapper
    }
    class TemplatePool extends Internal.TagEventJS<any> {
    get(id: Special.TemplatePoolTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.TemplatePoolTag, ...id: Special.TemplatePool[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.TemplatePoolTag, ...id: Special.TemplatePool[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.TemplatePoolTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.TemplatePool[]): Internal.TagEventJS$TagWrapper
    }
    class FlatLevelGeneratorPreset extends Internal.TagEventJS<any> {
    get(id: Special.FlatLevelGeneratorPresetTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.FlatLevelGeneratorPresetTag, ...id: Special.FlatLevelGeneratorPreset[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.FlatLevelGeneratorPresetTag, ...id: Special.FlatLevelGeneratorPreset[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.FlatLevelGeneratorPresetTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.FlatLevelGeneratorPreset[]): Internal.TagEventJS$TagWrapper
    }
    class GameEvent extends Internal.TagEventJS<any> {
    get(id: Special.GameEventTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.GameEventTag, ...id: Special.GameEvent[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.GameEventTag, ...id: Special.GameEvent[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.GameEventTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.GameEvent[]): Internal.TagEventJS$TagWrapper
    }
    class SoundEvent extends Internal.TagEventJS<any> {
    get(id: Special.SoundEventTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.SoundEventTag, ...id: Special.SoundEvent[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.SoundEventTag, ...id: Special.SoundEvent[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.SoundEventTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.SoundEvent[]): Internal.TagEventJS$TagWrapper
    }
    class Fluid extends Internal.TagEventJS<any> {
    get(id: Special.FluidTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.FluidTag, ...id: Special.Fluid[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.FluidTag, ...id: Special.Fluid[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.FluidTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.Fluid[]): Internal.TagEventJS$TagWrapper
    }
    class MobEffect extends Internal.TagEventJS<any> {
    get(id: Special.MobEffectTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.MobEffectTag, ...id: Special.MobEffect[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.MobEffectTag, ...id: Special.MobEffect[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.MobEffectTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.MobEffect[]): Internal.TagEventJS$TagWrapper
    }
    class Block extends Internal.TagEventJS<any> {
    get(id: Special.BlockTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.BlockTag, ...id: Special.Block[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.BlockTag, ...id: Special.Block[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.BlockTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.Block[]): Internal.TagEventJS$TagWrapper
    }
    class Enchantment extends Internal.TagEventJS<any> {
    get(id: Special.EnchantmentTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.EnchantmentTag, ...id: Special.Enchantment[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.EnchantmentTag, ...id: Special.Enchantment[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.EnchantmentTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.Enchantment[]): Internal.TagEventJS$TagWrapper
    }
    class EntityType extends Internal.TagEventJS<any> {
    get(id: Special.EntityTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.EntityTypeTag, ...id: Special.EntityType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.EntityTypeTag, ...id: Special.EntityType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.EntityTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.EntityType[]): Internal.TagEventJS$TagWrapper
    }
    class Item extends Internal.TagEventJS<any> {
    get(id: Special.ItemTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.ItemTag, ...id: Special.Item[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.ItemTag, ...id: Special.Item[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.ItemTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.Item[]): Internal.TagEventJS$TagWrapper
    }
    class Potion extends Internal.TagEventJS<any> {
    get(id: Special.PotionTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.PotionTag, ...id: Special.Potion[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.PotionTag, ...id: Special.Potion[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.PotionTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.Potion[]): Internal.TagEventJS$TagWrapper
    }
    class ParticleType extends Internal.TagEventJS<any> {
    get(id: Special.ParticleTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.ParticleTypeTag, ...id: Special.ParticleType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.ParticleTypeTag, ...id: Special.ParticleType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.ParticleTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.ParticleType[]): Internal.TagEventJS$TagWrapper
    }
    class BlockEntityType extends Internal.TagEventJS<any> {
    get(id: Special.BlockEntityTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.BlockEntityTypeTag, ...id: Special.BlockEntityType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.BlockEntityTypeTag, ...id: Special.BlockEntityType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.BlockEntityTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.BlockEntityType[]): Internal.TagEventJS$TagWrapper
    }
    class PaintingVariant extends Internal.TagEventJS<any> {
    get(id: Special.PaintingVariantTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.PaintingVariantTag, ...id: Special.PaintingVariant[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.PaintingVariantTag, ...id: Special.PaintingVariant[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.PaintingVariantTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.PaintingVariant[]): Internal.TagEventJS$TagWrapper
    }
    class CustomStat extends Internal.TagEventJS<any> {
    get(id: Special.CustomStatTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.CustomStatTag, ...id: Special.CustomStat[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.CustomStatTag, ...id: Special.CustomStat[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.CustomStatTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.CustomStat[]): Internal.TagEventJS$TagWrapper
    }
    class ChunkStatus extends Internal.TagEventJS<any> {
    get(id: Special.ChunkStatusTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.ChunkStatusTag, ...id: Special.ChunkStatus[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.ChunkStatusTag, ...id: Special.ChunkStatus[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.ChunkStatusTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.ChunkStatus[]): Internal.TagEventJS$TagWrapper
    }
    class RuleTest extends Internal.TagEventJS<any> {
    get(id: Special.RuleTestTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.RuleTestTag, ...id: Special.RuleTest[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.RuleTestTag, ...id: Special.RuleTest[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.RuleTestTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.RuleTest[]): Internal.TagEventJS$TagWrapper
    }
    class PosRuleTest extends Internal.TagEventJS<any> {
    get(id: Special.PosRuleTestTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.PosRuleTestTag, ...id: Special.PosRuleTest[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.PosRuleTestTag, ...id: Special.PosRuleTest[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.PosRuleTestTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.PosRuleTest[]): Internal.TagEventJS$TagWrapper
    }
    class Menu extends Internal.TagEventJS<any> {
    get(id: Special.MenuTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.MenuTag, ...id: Special.Menu[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.MenuTag, ...id: Special.Menu[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.MenuTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.Menu[]): Internal.TagEventJS$TagWrapper
    }
    class RecipeType extends Internal.TagEventJS<any> {
    get(id: Special.RecipeTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.RecipeTypeTag, ...id: Special.RecipeType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.RecipeTypeTag, ...id: Special.RecipeType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.RecipeTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.RecipeType[]): Internal.TagEventJS$TagWrapper
    }
    class RecipeSerializer extends Internal.TagEventJS<any> {
    get(id: Special.RecipeSerializerTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.RecipeSerializerTag, ...id: Special.RecipeSerializer[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.RecipeSerializerTag, ...id: Special.RecipeSerializer[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.RecipeSerializerTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.RecipeSerializer[]): Internal.TagEventJS$TagWrapper
    }
    class Attribute extends Internal.TagEventJS<any> {
    get(id: Special.AttributeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.AttributeTag, ...id: Special.Attribute[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.AttributeTag, ...id: Special.Attribute[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.AttributeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.Attribute[]): Internal.TagEventJS$TagWrapper
    }
    class PositionSourceType extends Internal.TagEventJS<any> {
    get(id: Special.PositionSourceTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.PositionSourceTypeTag, ...id: Special.PositionSourceType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.PositionSourceTypeTag, ...id: Special.PositionSourceType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.PositionSourceTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.PositionSourceType[]): Internal.TagEventJS$TagWrapper
    }
    class CommandArgumentType extends Internal.TagEventJS<any> {
    get(id: Special.CommandArgumentTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.CommandArgumentTypeTag, ...id: Special.CommandArgumentType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.CommandArgumentTypeTag, ...id: Special.CommandArgumentType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.CommandArgumentTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.CommandArgumentType[]): Internal.TagEventJS$TagWrapper
    }
    class StatType extends Internal.TagEventJS<any> {
    get(id: Special.StatTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.StatTypeTag, ...id: Special.StatType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.StatTypeTag, ...id: Special.StatType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.StatTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.StatType[]): Internal.TagEventJS$TagWrapper
    }
    class VillagerType extends Internal.TagEventJS<any> {
    get(id: Special.VillagerTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.VillagerTypeTag, ...id: Special.VillagerType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.VillagerTypeTag, ...id: Special.VillagerType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.VillagerTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.VillagerType[]): Internal.TagEventJS$TagWrapper
    }
    class VillagerProfession extends Internal.TagEventJS<any> {
    get(id: Special.VillagerProfessionTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.VillagerProfessionTag, ...id: Special.VillagerProfession[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.VillagerProfessionTag, ...id: Special.VillagerProfession[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.VillagerProfessionTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.VillagerProfession[]): Internal.TagEventJS$TagWrapper
    }
    class PointOfInterestType extends Internal.TagEventJS<any> {
    get(id: Special.PointOfInterestTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.PointOfInterestTypeTag, ...id: Special.PointOfInterestType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.PointOfInterestTypeTag, ...id: Special.PointOfInterestType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.PointOfInterestTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.PointOfInterestType[]): Internal.TagEventJS$TagWrapper
    }
    class MemoryModuleType extends Internal.TagEventJS<any> {
    get(id: Special.MemoryModuleTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.MemoryModuleTypeTag, ...id: Special.MemoryModuleType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.MemoryModuleTypeTag, ...id: Special.MemoryModuleType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.MemoryModuleTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.MemoryModuleType[]): Internal.TagEventJS$TagWrapper
    }
    class SensorType extends Internal.TagEventJS<any> {
    get(id: Special.SensorTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.SensorTypeTag, ...id: Special.SensorType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.SensorTypeTag, ...id: Special.SensorType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.SensorTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.SensorType[]): Internal.TagEventJS$TagWrapper
    }
    class Schedule extends Internal.TagEventJS<any> {
    get(id: Special.ScheduleTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.ScheduleTag, ...id: Special.Schedule[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.ScheduleTag, ...id: Special.Schedule[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.ScheduleTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.Schedule[]): Internal.TagEventJS$TagWrapper
    }
    class Activity extends Internal.TagEventJS<any> {
    get(id: Special.ActivityTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.ActivityTag, ...id: Special.Activity[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.ActivityTag, ...id: Special.Activity[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.ActivityTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.Activity[]): Internal.TagEventJS$TagWrapper
    }
    class LootPoolEntryType extends Internal.TagEventJS<any> {
    get(id: Special.LootPoolEntryTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.LootPoolEntryTypeTag, ...id: Special.LootPoolEntryType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.LootPoolEntryTypeTag, ...id: Special.LootPoolEntryType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.LootPoolEntryTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.LootPoolEntryType[]): Internal.TagEventJS$TagWrapper
    }
    class LootFunctionType extends Internal.TagEventJS<any> {
    get(id: Special.LootFunctionTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.LootFunctionTypeTag, ...id: Special.LootFunctionType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.LootFunctionTypeTag, ...id: Special.LootFunctionType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.LootFunctionTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.LootFunctionType[]): Internal.TagEventJS$TagWrapper
    }
    class LootConditionType extends Internal.TagEventJS<any> {
    get(id: Special.LootConditionTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.LootConditionTypeTag, ...id: Special.LootConditionType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.LootConditionTypeTag, ...id: Special.LootConditionType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.LootConditionTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.LootConditionType[]): Internal.TagEventJS$TagWrapper
    }
    class LootNumberProviderType extends Internal.TagEventJS<any> {
    get(id: Special.LootNumberProviderTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.LootNumberProviderTypeTag, ...id: Special.LootNumberProviderType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.LootNumberProviderTypeTag, ...id: Special.LootNumberProviderType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.LootNumberProviderTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.LootNumberProviderType[]): Internal.TagEventJS$TagWrapper
    }
    class LootNbtProviderType extends Internal.TagEventJS<any> {
    get(id: Special.LootNbtProviderTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.LootNbtProviderTypeTag, ...id: Special.LootNbtProviderType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.LootNbtProviderTypeTag, ...id: Special.LootNbtProviderType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.LootNbtProviderTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.LootNbtProviderType[]): Internal.TagEventJS$TagWrapper
    }
    class LootScoreProviderType extends Internal.TagEventJS<any> {
    get(id: Special.LootScoreProviderTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.LootScoreProviderTypeTag, ...id: Special.LootScoreProviderType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.LootScoreProviderTypeTag, ...id: Special.LootScoreProviderType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.LootScoreProviderTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.LootScoreProviderType[]): Internal.TagEventJS$TagWrapper
    }
    class FloatProviderType extends Internal.TagEventJS<any> {
    get(id: Special.FloatProviderTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.FloatProviderTypeTag, ...id: Special.FloatProviderType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.FloatProviderTypeTag, ...id: Special.FloatProviderType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.FloatProviderTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.FloatProviderType[]): Internal.TagEventJS$TagWrapper
    }
    class IntProviderType extends Internal.TagEventJS<any> {
    get(id: Special.IntProviderTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.IntProviderTypeTag, ...id: Special.IntProviderType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.IntProviderTypeTag, ...id: Special.IntProviderType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.IntProviderTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.IntProviderType[]): Internal.TagEventJS$TagWrapper
    }
    class HeightProviderType extends Internal.TagEventJS<any> {
    get(id: Special.HeightProviderTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.HeightProviderTypeTag, ...id: Special.HeightProviderType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.HeightProviderTypeTag, ...id: Special.HeightProviderType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.HeightProviderTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.HeightProviderType[]): Internal.TagEventJS$TagWrapper
    }
    class BlockPredicateType extends Internal.TagEventJS<any> {
    get(id: Special.BlockPredicateTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.BlockPredicateTypeTag, ...id: Special.BlockPredicateType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.BlockPredicateTypeTag, ...id: Special.BlockPredicateType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.BlockPredicateTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.BlockPredicateType[]): Internal.TagEventJS$TagWrapper
    }
    class Carver extends Internal.TagEventJS<any> {
    get(id: Special.CarverTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.CarverTag, ...id: Special.Carver[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.CarverTag, ...id: Special.Carver[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.CarverTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.Carver[]): Internal.TagEventJS$TagWrapper
    }
    class Feature extends Internal.TagEventJS<any> {
    get(id: Special.FeatureTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.FeatureTag, ...id: Special.Feature[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.FeatureTag, ...id: Special.Feature[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.FeatureTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.Feature[]): Internal.TagEventJS$TagWrapper
    }
    class StructurePlacement extends Internal.TagEventJS<any> {
    get(id: Special.StructurePlacementTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.StructurePlacementTag, ...id: Special.StructurePlacement[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.StructurePlacementTag, ...id: Special.StructurePlacement[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.StructurePlacementTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.StructurePlacement[]): Internal.TagEventJS$TagWrapper
    }
    class StructurePiece extends Internal.TagEventJS<any> {
    get(id: Special.StructurePieceTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.StructurePieceTag, ...id: Special.StructurePiece[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.StructurePieceTag, ...id: Special.StructurePiece[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.StructurePieceTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.StructurePiece[]): Internal.TagEventJS$TagWrapper
    }
    class StructureType extends Internal.TagEventJS<any> {
    get(id: Special.StructureTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.StructureTypeTag, ...id: Special.StructureType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.StructureTypeTag, ...id: Special.StructureType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.StructureTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.StructureType[]): Internal.TagEventJS$TagWrapper
    }
    class PlacementModifierType extends Internal.TagEventJS<any> {
    get(id: Special.PlacementModifierTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.PlacementModifierTypeTag, ...id: Special.PlacementModifierType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.PlacementModifierTypeTag, ...id: Special.PlacementModifierType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.PlacementModifierTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.PlacementModifierType[]): Internal.TagEventJS$TagWrapper
    }
    class BlockStateProviderType extends Internal.TagEventJS<any> {
    get(id: Special.BlockStateProviderTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.BlockStateProviderTypeTag, ...id: Special.BlockStateProviderType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.BlockStateProviderTypeTag, ...id: Special.BlockStateProviderType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.BlockStateProviderTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.BlockStateProviderType[]): Internal.TagEventJS$TagWrapper
    }
    class FoliagePlacerType extends Internal.TagEventJS<any> {
    get(id: Special.FoliagePlacerTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.FoliagePlacerTypeTag, ...id: Special.FoliagePlacerType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.FoliagePlacerTypeTag, ...id: Special.FoliagePlacerType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.FoliagePlacerTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.FoliagePlacerType[]): Internal.TagEventJS$TagWrapper
    }
    class TrunkPlacerType extends Internal.TagEventJS<any> {
    get(id: Special.TrunkPlacerTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.TrunkPlacerTypeTag, ...id: Special.TrunkPlacerType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.TrunkPlacerTypeTag, ...id: Special.TrunkPlacerType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.TrunkPlacerTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.TrunkPlacerType[]): Internal.TagEventJS$TagWrapper
    }
    class RootPlacerType extends Internal.TagEventJS<any> {
    get(id: Special.RootPlacerTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.RootPlacerTypeTag, ...id: Special.RootPlacerType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.RootPlacerTypeTag, ...id: Special.RootPlacerType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.RootPlacerTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.RootPlacerType[]): Internal.TagEventJS$TagWrapper
    }
    class TreeDecoratorType extends Internal.TagEventJS<any> {
    get(id: Special.TreeDecoratorTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.TreeDecoratorTypeTag, ...id: Special.TreeDecoratorType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.TreeDecoratorTypeTag, ...id: Special.TreeDecoratorType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.TreeDecoratorTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.TreeDecoratorType[]): Internal.TagEventJS$TagWrapper
    }
    class FeatureSizeType extends Internal.TagEventJS<any> {
    get(id: Special.FeatureSizeTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.FeatureSizeTypeTag, ...id: Special.FeatureSizeType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.FeatureSizeTypeTag, ...id: Special.FeatureSizeType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.FeatureSizeTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.FeatureSizeType[]): Internal.TagEventJS$TagWrapper
    }
    class BiomeSource extends Internal.TagEventJS<any> {
    get(id: Special.BiomeSourceTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.BiomeSourceTag, ...id: Special.BiomeSource[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.BiomeSourceTag, ...id: Special.BiomeSource[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.BiomeSourceTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.BiomeSource[]): Internal.TagEventJS$TagWrapper
    }
    class ChunkGenerator extends Internal.TagEventJS<any> {
    get(id: Special.ChunkGeneratorTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.ChunkGeneratorTag, ...id: Special.ChunkGenerator[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.ChunkGeneratorTag, ...id: Special.ChunkGenerator[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.ChunkGeneratorTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.ChunkGenerator[]): Internal.TagEventJS$TagWrapper
    }
    class MaterialCondition extends Internal.TagEventJS<any> {
    get(id: Special.MaterialConditionTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.MaterialConditionTag, ...id: Special.MaterialCondition[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.MaterialConditionTag, ...id: Special.MaterialCondition[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.MaterialConditionTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.MaterialCondition[]): Internal.TagEventJS$TagWrapper
    }
    class MaterialRule extends Internal.TagEventJS<any> {
    get(id: Special.MaterialRuleTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.MaterialRuleTag, ...id: Special.MaterialRule[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.MaterialRuleTag, ...id: Special.MaterialRule[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.MaterialRuleTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.MaterialRule[]): Internal.TagEventJS$TagWrapper
    }
    class DensityFunctionType extends Internal.TagEventJS<any> {
    get(id: Special.DensityFunctionTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.DensityFunctionTypeTag, ...id: Special.DensityFunctionType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.DensityFunctionTypeTag, ...id: Special.DensityFunctionType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.DensityFunctionTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.DensityFunctionType[]): Internal.TagEventJS$TagWrapper
    }
    class StructureProcessor extends Internal.TagEventJS<any> {
    get(id: Special.StructureProcessorTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.StructureProcessorTag, ...id: Special.StructureProcessor[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.StructureProcessorTag, ...id: Special.StructureProcessor[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.StructureProcessorTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.StructureProcessor[]): Internal.TagEventJS$TagWrapper
    }
    class StructurePoolElement extends Internal.TagEventJS<any> {
    get(id: Special.StructurePoolElementTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.StructurePoolElementTag, ...id: Special.StructurePoolElement[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.StructurePoolElementTag, ...id: Special.StructurePoolElement[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.StructurePoolElementTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.StructurePoolElement[]): Internal.TagEventJS$TagWrapper
    }
    class CatVariant extends Internal.TagEventJS<any> {
    get(id: Special.CatVariantTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.CatVariantTag, ...id: Special.CatVariant[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.CatVariantTag, ...id: Special.CatVariant[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.CatVariantTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.CatVariant[]): Internal.TagEventJS$TagWrapper
    }
    class FrogVariant extends Internal.TagEventJS<any> {
    get(id: Special.FrogVariantTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.FrogVariantTag, ...id: Special.FrogVariant[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.FrogVariantTag, ...id: Special.FrogVariant[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.FrogVariantTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.FrogVariant[]): Internal.TagEventJS$TagWrapper
    }
    class BannerPattern extends Internal.TagEventJS<any> {
    get(id: Special.BannerPatternTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.BannerPatternTag, ...id: Special.BannerPattern[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.BannerPatternTag, ...id: Special.BannerPattern[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.BannerPatternTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.BannerPattern[]): Internal.TagEventJS$TagWrapper
    }
    class Instrument extends Internal.TagEventJS<any> {
    get(id: Special.InstrumentTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.InstrumentTag, ...id: Special.Instrument[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.InstrumentTag, ...id: Special.Instrument[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.InstrumentTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.Instrument[]): Internal.TagEventJS$TagWrapper
    }
    class Brews extends Internal.TagEventJS<any> {
    get(id: Special.BrewsTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.BrewsTag, ...id: Special.Brews[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.BrewsTag, ...id: Special.Brews[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.BrewsTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.Brews[]): Internal.TagEventJS$TagWrapper
    }
    class TransformerSerializer extends Internal.TagEventJS<any> {
    get(id: Special.TransformerSerializerTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.TransformerSerializerTag, ...id: Special.TransformerSerializer[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.TransformerSerializerTag, ...id: Special.TransformerSerializer[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.TransformerSerializerTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.TransformerSerializer[]): Internal.TagEventJS$TagWrapper
    }
    class ConditionSerializer extends Internal.TagEventJS<any> {
    get(id: Special.ConditionSerializerTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.ConditionSerializerTag, ...id: Special.ConditionSerializer[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.ConditionSerializerTag, ...id: Special.ConditionSerializer[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.ConditionSerializerTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.ConditionSerializer[]): Internal.TagEventJS$TagWrapper
    }
    class Gas extends Internal.TagEventJS<any> {
    get(id: Special.GasTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.GasTag, ...id: Special.Gas[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.GasTag, ...id: Special.Gas[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.GasTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.Gas[]): Internal.TagEventJS$TagWrapper
    }
    class InfuseType extends Internal.TagEventJS<any> {
    get(id: Special.InfuseTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.InfuseTypeTag, ...id: Special.InfuseType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.InfuseTypeTag, ...id: Special.InfuseType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.InfuseTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.InfuseType[]): Internal.TagEventJS$TagWrapper
    }
    class Pigment extends Internal.TagEventJS<any> {
    get(id: Special.PigmentTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.PigmentTag, ...id: Special.Pigment[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.PigmentTag, ...id: Special.Pigment[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.PigmentTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.Pigment[]): Internal.TagEventJS$TagWrapper
    }
    class Slurry extends Internal.TagEventJS<any> {
    get(id: Special.SlurryTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.SlurryTag, ...id: Special.Slurry[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.SlurryTag, ...id: Special.Slurry[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.SlurryTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.Slurry[]): Internal.TagEventJS$TagWrapper
    }
    class EntityDataSerializers extends Internal.TagEventJS<any> {
    get(id: Special.EntityDataSerializersTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.EntityDataSerializersTag, ...id: Special.EntityDataSerializers[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.EntityDataSerializersTag, ...id: Special.EntityDataSerializers[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.EntityDataSerializersTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.EntityDataSerializers[]): Internal.TagEventJS$TagWrapper
    }
    class GlobalLootModifierSerializers extends Internal.TagEventJS<any> {
    get(id: Special.GlobalLootModifierSerializersTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.GlobalLootModifierSerializersTag, ...id: Special.GlobalLootModifierSerializers[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.GlobalLootModifierSerializersTag, ...id: Special.GlobalLootModifierSerializers[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.GlobalLootModifierSerializersTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.GlobalLootModifierSerializers[]): Internal.TagEventJS$TagWrapper
    }
    class FluidType extends Internal.TagEventJS<any> {
    get(id: Special.FluidTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.FluidTypeTag, ...id: Special.FluidType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.FluidTypeTag, ...id: Special.FluidType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.FluidTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.FluidType[]): Internal.TagEventJS$TagWrapper
    }
    class Grist extends Internal.TagEventJS<any> {
    get(id: Special.GristTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.GristTag, ...id: Special.Grist[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.GristTag, ...id: Special.Grist[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.GristTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.Grist[]): Internal.TagEventJS$TagWrapper
    }
    class TerrainLandType extends Internal.TagEventJS<any> {
    get(id: Special.TerrainLandTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.TerrainLandTypeTag, ...id: Special.TerrainLandType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.TerrainLandTypeTag, ...id: Special.TerrainLandType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.TerrainLandTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.TerrainLandType[]): Internal.TagEventJS$TagWrapper
    }
    class TitleLandType extends Internal.TagEventJS<any> {
    get(id: Special.TitleLandTypeTag): Internal.TagEventJS$TagWrapper
    add(tag: Special.TitleLandTypeTag, ...id: Special.TitleLandType[]): Internal.TagEventJS$TagWrapper
    remove(tag: Special.TitleLandTypeTag, ...id: Special.TitleLandType[]): Internal.TagEventJS$TagWrapper
    removeAll(tag: Special.TitleLandTypeTag): Internal.TagEventJS$TagWrapper
    removeAllTagsFrom(...id: Special.TitleLandType[]): Internal.TagEventJS$TagWrapper
    }
}