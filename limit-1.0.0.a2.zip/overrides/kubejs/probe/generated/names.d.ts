/// <reference path="./globals.d.ts" />
const Vec3d: typeof Vec3
const PonderInput: typeof PonderInputWindowElement
const Direction: typeof Facing
const Text: typeof Component
